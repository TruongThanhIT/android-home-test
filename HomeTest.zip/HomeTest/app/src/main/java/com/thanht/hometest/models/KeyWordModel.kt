package com.thanht.hometest.models

data class KeyWordModel(val value: String, val color: Int)